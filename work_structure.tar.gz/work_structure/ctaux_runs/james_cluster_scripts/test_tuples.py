import sys
#uncomment to run on garching
#sys.path.append('/u/jleblanc/software/h5py-2.0.1/base/usr/local/lib64/python2.6/site-packages')
import sys, getopt;
import os, os.path, shutil, distutils.dir_util,numpy,h5py
from numpy import array,average
import re

from collections import namedtuple

student_tuples=[]

print student_tuples

student_tuples = [
        ('john', 'A', 15),
        ('jane', 'B', 12),
        ('dave', 'B', 10),
]

sorted(student_tuples, key=lambda student: student[2])

print student_tuples

for item in student_tuples:
	print item[2]










