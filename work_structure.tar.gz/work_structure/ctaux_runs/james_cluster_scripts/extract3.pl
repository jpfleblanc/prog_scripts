use strict;

my $nfreq = shift;

open CTHF_PARMS, "<ctaux.param";
my $sites = 0;
while (<CTHF_PARMS>) {
   print if /^U \s*=/; 
   print if /^BETA\s*=/; 
   print if /^MU \s*=/; 
   print if /^t.*=/; 
   print if /^PARAMAGNET.*=/ ;
   print if /^FLAVORS\s*=/;
   print if /^LATTICE\s*=/;
   print if /^LATTICE_LIBRARY\s*=/;
   print if /^L\s*=/;
   if (/^SITES\s*=\s*(\d+)/) {
       print;
       $sites = $1;
   }
}
close CTHF_PARMS;

print "NFREQ = $nfreq\n";
my $maxit = 0;
foreach (glob "selfenergy_[0-9]*") {
   my ($it) = /selfenergy_(\d+)/;
   $maxit = $it if $it>$maxit;
}

print "SELFENERGY_FILE = selfenergy_", $maxit, "\n";

my $density = 0;
my $densout = `h5dump -d /simulation/results/density_up_times_sign/mean/value sim.h5`;
$densout .= `h5dump -d /simulation/results/density_down_times_sign/mean/value sim.h5`;
while ($densout =~/[,:] /sg) {
   $density += $1 if $densout=~/\G([\-0-9.eE]+)/;
}
$density /= 2.*$sites;
print "DENSITY = ", $density, "\n";

my $doubleoc = 0;
my $doubleout = `h5dump -d /simulation/results/doubleoc_times_sign/mean/value sim.h5`;
pos($doubleout) = 0;
while ($doubleout =~/[,:] /sg) {
   $doubleoc += $1 if $doubleout=~/\G([\-0-9.eE]+)/;
}
$doubleoc /= $sites;
print "DOUBLE_OCCUPANCY = ", $doubleoc, "\n";


my $ni_nj_out = `h5dump -d /simulation/results/ni_nj_times_sign/mean/value sim.h5`;
my $i =0;
while ($ni_nj_out =~/[,:] /sg) {
   my ($ni_nj) = $ni_nj_out=~/\G([\-0-9.eE]+)/;
   print "ni_nj_", $i, " = ", $ni_nj, "\n";
   $i++;
}

# my $monster_out = `h5dump -d /simulation/results/experimental_correlator/mean/value sim.h5`;
# $i =0;
# while ($monster_out =~/[,:] /sg) {
#     my ($monster) = $monster_out=~/\G([\-0-9.eE]+)/;
#     print "monster_", $i, " = ", $monster, "\n";
#     $i++;
# }

for my $i (0..$sites*$sites-1) {
   print "monster_", $i, " = 0\n";
}



