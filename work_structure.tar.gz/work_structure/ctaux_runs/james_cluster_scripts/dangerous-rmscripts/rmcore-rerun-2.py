import sys
#uncomment to run on garching
sys.path.append('/u/jleblanc/software/h5py-2.0.1/base/usr/local/lib64/python2.6/site-packages')
import sys, getopt;
import os, os.path, shutil, distutils.dir_util,numpy,h5py
from numpy import array,average
import re
import math

from collections import namedtuple

#simStructure = namedtuple("simStructure", "density mu sites")

def natural_sort(l): 
    convert = lambda text: int(text) if text.isdigit() else text.lower() 
    alphanum_key = lambda key: [ convert(c) for c in re.split('([0-9]+)', key) ] 
    return sorted(l, key = alphanum_key)


def main(argv):
#  U="8"
#  LATTICE="Betts2D-1A"
#  SITES=1
#  try:                                
#    opts, args = getopt.getopt(argv, "hULs", ["help", "U=", "lattice=","sites="])
#  except getopt.GetoptError:          
#    usage()                         
#    sys.exit(2)                     
#  for opt, arg in opts:
#    if opt in ("-h", "--help"):
#      usage()                     
#      sys.exit()                  
#    elif opt in("-L","--lattice"):
#      LATTICE = arg                 
#    elif opt in ("-U", "--U"):
#      U = arg 
#    elif opt in ("-s", "--sites"):
#      SITES =arg 
  eval()

def usage():
  print("call program with -U for U, --sites= for # sites, --lattice= for lattice")

def eval():
 
	sitelist=[]
	site_folderlist=[]

	fileslist=[]

	temp_mu_folders=[]
	fig1b=[]

	start_directory=os.getcwd()
	print("Starting in "+start_directory)
	
#	files = filter(os.path.isfile, os.listdir('.')) 
	dirs = filter(os.path.isdir, os.listdir('.'))  

#	for dir_items in dirs:
#		print("Directories are "+ dir_items)
		
	for dir_items in dirs:
		os.chdir(start_directory + "/"+dir_items)
		files = filter(os.path.isfile, os.listdir('.'))
		
		for file_items in files:
			if "core" in file_items:
				print os.getcwd()	
				for new_items in files:
					if "G0_omega_input" in new_items:
						if "realspace" not in new_items:
							print new_items
							#shutil.copy(new_items, "garbage")
							os.rename("G0_omega_input","temp")
							


							os.system("rm -f G* g* self* errfile outfile tmp* core sim.h5" )
							os.rename("temp","G0_omega_input")
							if "james_submit-rerun.pbs" in new_items:
								os.system("qsub james_submit-rerun.pbs")	
								os.system("echo 'blah' > inqueue.txt")
							else:
								os.system("qsub james_submit.pbs")
								os.system("echo 'blah' > inqueue.txt")							
			#print len(files)
			
		
			
	

if __name__ == "__main__":
    main(sys.argv[1:])






