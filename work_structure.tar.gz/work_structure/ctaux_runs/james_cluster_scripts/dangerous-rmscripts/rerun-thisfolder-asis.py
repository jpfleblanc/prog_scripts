import os, shutil, distutils.dir_util


if os.path.isfile("G0_omega_input"):
	os.system("mv G0_omega_input TEMP && rm -f G* g* self* errfile outfile tmp* sim.h5 core && mv TEMP G0_omega_input && qsub james_submit-rerun.pbs")




