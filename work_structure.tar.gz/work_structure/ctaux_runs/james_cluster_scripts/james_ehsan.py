import sys
#uncomment to run on garching
sys.path.append('/u/jleblanc/software/h5py-2.0.1/base/usr/local/lib64/python2.6/site-packages')
import sys, getopt;
import os, os.path, shutil, distutils.dir_util,numpy,h5py
from numpy import array,average
import re
import math

from collections import namedtuple

#simStructure = namedtuple("simStructure", "density mu sites")

def natural_sort(l): 
    convert = lambda text: int(text) if text.isdigit() else text.lower() 
    alphanum_key = lambda key: [ convert(c) for c in re.split('([0-9]+)', key) ] 
    return sorted(l, key = alphanum_key)


def main(argv):
#  U="8"
#  LATTICE="Betts2D-1A"
#  SITES=1
#  try:                                
#    opts, args = getopt.getopt(argv, "hULs", ["help", "U=", "lattice=","sites="])
#  except getopt.GetoptError:          
#    usage()                         
#    sys.exit(2)                     
#  for opt, arg in opts:
#    if opt in ("-h", "--help"):
#      usage()                     
#      sys.exit()                  
#    elif opt in("-L","--lattice"):
#      LATTICE = arg                 
#    elif opt in ("-U", "--U"):
#      U = arg 
#    elif opt in ("-s", "--sites"):
#      SITES =arg 
  eval()

def usage():
  print("call program with -U for U, --sites= for # sites, --lattice= for lattice")

def eval():
 
	sitelist=[]
	site_folderlist=[]

	temp_mu_folders=[]
	fig1b=[]

	start_directory=os.getcwd()
	print("Starting in "+start_directory)
	
	files = filter(os.path.isfile, os.listdir('.')) 
	dirs = filter(os.path.isdir, os.listdir('.'))  

	print("Files are " +str(files))
	print("Directories are " +str(dirs))

	for dir_items in dirs:
		print("Directories are "+ dir_items)
		
	for dir_items in dirs:
		if "Betts2D" in dir_items:
			print("Betts folders are " + dir_items)
			site_folderlist.append(dir_items)
			sitenum=dir_items[8:-1].strip()			
			sitelist.append(sitenum)	
  	print sitelist	
	sitelist=natural_sort(sitelist)
	site_folderlist=natural_sort(site_folderlist)
	print("Available site folders are ")
	print site_folderlist

	

# ---------------- Now move into Betts directories


	for item in site_folderlist:
		os.chdir(start_directory + "/"+ item)
		print("cd " + start_directory + "/"+ item)
		print("I am in " + os.getcwd())
		temp_mu_folders=filter(os.path.isdir, os.listdir('.'))
		

# --------- check for sim.h5 files
		for folder_item in temp_mu_folders:
			if os.path.exists(os.getcwd()+"/"+folder_item+"/sim.h5"):
				print("sim.h5 exists in folder"+os.getcwd()+"/"+folder_item+"/sim.h5")
				
				
#--------- read in relevant data from sim.h5
				f = h5py.File(os.getcwd()+"/"+folder_item+"/sim.h5", 'r')

				if f["/parameters/MU"].value<=0:
					density_mean =(f["/simulation/results/density_up_times_sign/mean/value"].value+f["/simulation/results/density_down_times_sign/mean/value"].value)*0.5
					density_mean = sum(density_mean)/float(len(density_mean))
					print density_mean
      					density_mean_err =(f["/simulation/results/density_up_times_sign/mean/error"].value+f["/simulation/results/density_down_times_sign/mean/error"].value)*0.5
					density_mean_err = sum(density_mean_err)/math.sqrt(float(len(density_mean_err)))
					print density_mean_err
#sum(i*i for i in density_mean_err)

					mu=f["/parameters/MU"].value
					site=f["/parameters/SITES"].value

					print mu, site 		
#---------- all data in following list			
					fig1b.append( ( mu, density_mean, density_mean_err, site))

	os.chdir(start_directory)
	datasite=[]

#	sorted(myList, key=lambda x: x[1])
# sort data in list to get what you want 

	
	
	for item in fig1b:
		#print item	
		if item[3]==16:
			datasite.append((item[0], item[1], item[2]))
		
	datasite=sorted(datasite, key=lambda x: x[0])
	print datasite
	for item in datasite:	
		print item[0]

# print to file
	fig1b_file = open('fig1b.dat', 'w+')
	for item in datasite:
		fig1b_file.write(str(item[0])+" "+str(item[1])+" "+str(item[2])+"\n")

	

if __name__ == "__main__":
    main(sys.argv[1:])






