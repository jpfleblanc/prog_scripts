import sys
#uncomment to run on garching
sys.path.append('/opt/apps/intel15/python/2.7.9/lib/python2.7/site-packages/')
import sys, getopt;
import os, os.path, shutil, distutils.dir_util,numpy,h5py
from numpy import array,average
import re
import math
import resource
from numpy import *

from linreg import linreg

from collections import namedtuple

#simStructure = namedtuple("simStructure", "density mu sites")

def natural_sort(l): 
    convert = lambda text: int(text) if text.isdigit() else text.lower() 
    alphanum_key = lambda key: [ convert(c) for c in re.split('([0-9]+)', key) ] 
    return sorted(l, key = alphanum_key)


def get_neighbour_dist():

	output=[]
	for i in range (0, 10):
		for j in range (0, i+1):
			
			length=math.sqrt(math.pow(i,2)+ math.pow(j,2))
			#print i, j, length, length*length			
			if length not in output:
				output.append(length)

	output=sorted(output, key=lambda x: x)
	return output


def main(argv):
#  U="8"
#  LATTICE="Betts2D-1A"
#  SITES=1
#  try:                                
#    opts, args = getopt.getopt(argv, "hULs", ["help", "U=", "lattice=","sites="])
#  except getopt.GetoptError:          
#    usage()                         
#    sys.exit(2)                     
#  for opt, arg in opts:
#    if opt in ("-h", "--help"):
#      usage()                     
#      sys.exit()                  
#    elif opt in("-L","--lattice"):
#      LATTICE = arg                 
#    elif opt in ("-U", "--U"):
#      U = arg 
#    elif opt in ("-s", "--sites"):
#      SITES =arg 
  resource.setrlimit(resource.RLIMIT_NOFILE, (4096, 4096))
  eval()

def usage():
  print("call program with -U for U, --sites= for # sites, --lattice= for lattice")

def eval():
 
	sitelist=[]
	site_folderlist=[]

	fileslist=[]

	temp_mu_folders=[]
	fig1b=[]

	start_directory=os.getcwd()
	print("Starting in "+start_directory)
	
	files = filter(os.path.isfile, os.listdir('.')) 
	dirs = filter(os.path.isdir, os.listdir('.'))  

	
# ---------------- Now move into Betts directories


	
	print("I am in " + os.getcwd())
	temp_mu_folders=filter(os.path.isdir, os.listdir('.'))
	

# --------- check for sim.h5 files
	for folder_item in temp_mu_folders:
		if os.path.exists(os.getcwd()+"/"+folder_item+"/sim.h5"):
			#print("sim.h5 exists in folder"+os.getcwd()+"/"+folder_item+"/sim.h5")
			
			
#--------- read in relevant data from sim.h5
			f = h5py.File(os.getcwd()+"/"+folder_item+"/sim.h5", 'r')

			#print folder_item
			#print f["/parameters/MU"].value
			if f["/parameters/MU"].value<=0 and folder_item =="Betts2D-32A_U3.0_T0.05_fill1.0_tp0.0":
				print folder_item
				density_mean =(f["/simulation/results/density_up/mean/value"].value+f["/simulation/results/density_down/mean/value"].value)*0.5
				density_mean = sum(density_mean)/float(len(density_mean))
				print density_mean
  				density_mean_err =(f["/simulation/results/density_up/mean/error"].value+f["/simulation/results/density_down/mean/error"].value)*0.5
				density_mean_err = sum(density_mean_err)/math.sqrt(float(len(density_mean_err)))
				print density_mean_err
#sum(i*i for i in density_mean_err)


				doubleoc_mean=(f["/simulation/results/doubleoc/mean/value"].value)	
				doubleoc_mean= sum(doubleoc_mean)/float(len(doubleoc_mean))	
  				doubleoc_error=(f["/simulation/results/doubleoc/mean/error"].value)
				doubleoc_error=sum(doubleoc_error)/float(len(doubleoc_error))

				sz2_mean=(f["/simulation/results/Sz_2/mean/value"].value)
				sz2_mean= sum(sz2_mean)/float(len(sz2_mean))	
				sz2_error=(f["/simulation/results/Sz_2/mean/error"].value)
				sz2_error= sum(sz2_error)/float(len(sz2_error))

				ninj_mean=(f["/simulation/results/ni_nj/mean/value"].value)
				ninj_error=(f["/simulation/results/ni_nj/mean/error"].value)
  					
				mu=f["/parameters/MU"].value
				site=int(f["/parameters/SITES"].value)
				beta=f["/parameters/BETA"].value
				T=1.0/float(beta)
				nfreq=f["/parameters/NMATSUBARA"].value	
				Uvalue=f["/parameters/U"].value	

#------- Got ninj
				
				print "Printing Ninj \n"
				print ninj_mean


#--------- Get Cluster coordinates

#				os.chdir(os.getcwd()+ '/'+folder_item)

				read_file=open('/work/03773/jamesleb/ctaux_runs//cluster-coords/ClusterCoordinates'+str(site), 'r')
				label, xval, yval  = numpy.loadtxt(read_file, usecols=(0,1,2), unpack=True)
				read_file.close()
				
				print label
				print xval
				print yval

				if (site==20):	
					ax=2.0
					ay=4.0
					bx=4.0
					by=-2.0
				if (site==32):
					ax=4.0
					ay=4.0
					bx=4.0
					by=-4.0
				if (site==34):
					ax=3.0
					ay=5.0
					bx=5.0
					by=-3.0
				if (site==50):
					ax=5.0
					ay=5.0
					bx=5.0
					by=-5.0
				if (site==64):
					ax=8.0
					ay=0.0
					bx=0.0
					by=8.0
				if (site==128):
					ax=8.0
					ay=8.0
					bx=8.0
					by=-8.0

				topval=40

				nntest=zeros((site,site,topval)).astype(int)
				#print nntest
				#print nntest[1][1]



#------------------------------		
				distance=get_neighbour_dist()
				print "Distance list length"
				print len(distance)

				
				length1=zeros(topval)
				length2=zeros(topval)
				length3=zeros(topval)
				length4=zeros(topval)
				length5=zeros(topval)
				length6=zeros(topval)
				length7=zeros(topval)
				length8=zeros(topval)
				length9=zeros(topval)
		
				



				for x in range (0, topval):
					for i in range (0, site):
						counter=0
						for j in range (0, site):
							length1[x]=math.fabs(math.sqrt( math.pow((xval[j]-xval[i]),2) + math.pow((yval[j]-yval[i]),2))-distance[x])
							length2[x]=math.fabs(math.sqrt( math.pow((xval[j]+ax-xval[i]),2) + math.pow((yval[j]+ay-yval[i]),2))-distance[x])
							length3[x]=math.fabs(math.sqrt( math.pow((xval[j]-ax-xval[i]),2) + math.pow((yval[j]-ay-yval[i]),2))-distance[x])
							length4[x]=math.fabs(math.sqrt( math.pow((xval[j]+bx-xval[i]),2) + math.pow((yval[j]+by-yval[i]),2))-distance[x])
							length5[x]=math.fabs(math.sqrt( math.pow((xval[j]-bx-xval[i]),2) + math.pow((yval[j]-by-yval[i]),2))-distance[x])
							length6[x]=math.fabs(math.sqrt( math.pow((xval[j]+ax+bx-xval[i]),2) + math.pow((yval[j]+ay+by-yval[i]),2))-distance[x])
							length7[x]=math.fabs(math.sqrt( math.pow((xval[j]-ax-bx-xval[i]),2) + math.pow((yval[j]-ay-by-yval[i]),2))-distance[x])
							length8[x]=math.fabs(math.sqrt( math.pow((xval[j]+ax-bx-xval[i]),2) + math.pow((yval[j]+ay-by-yval[i]),2))-distance[x])
							length9[x]=math.fabs(math.sqrt( math.pow((xval[j]-ax+bx-xval[i]),2) + math.pow((yval[j]-ay+by-yval[i]),2))-distance[x])

							#print length1[x]
							#print length2[x]
							#print length3[x]
							#print length4[x]
							#print length5[x]
							#print length6[x]
							#print length7[x]
							#print length8[x]
							#print length9[x]


							if (i ==j and i==0 and x==0):
								print "HERE"
								print length1[0]
							#print length1
							if (length1[x] < 0.01 or length2[x] <0.01 or length3[x] <0.01 or length4[x] <0.01 or length5[x] <0.01 or length6[x] <0.01 or length7[x] <0.01 or length8[x] < 0.01 or length9[x] < 0.01 ):
								counter+=1
								nntest[i][j][x]=1
								

					
					print nntest[1][1][0], nntest[1][0][0]
					#print nntest[0]
	
				

					print "There were "+str(counter)+" nearest neighbours"
					if (counter != 4):
						print "Something wasn't found! ABORT!!!"

#-------------------------------
#  now have the ninj's AND their nearest neighbour choices

				nuu=zeros((site,site))
				nud=zeros((site,site))
				ndu=zeros((site,site))
				ndd=zeros((site,site))
				nuue=zeros((site,site))
				nude=zeros((site,site))
				ndue=zeros((site,site))
				ndde=zeros((site,site))
				sz=zeros(topval)
				sze=zeros(topval)
				sznew=zeros(topval)
				totalcount=zeros(topval)
				for x in range (0,topval):
					#print "X is "+str(x)
					for i in range (0, 1):
						for j in range (0, site):
							nuu[i][j]=ninj_mean[4*site*i+4*j]
							nud[i][j]=ninj_mean[4*site*i+4*j+1]
							ndu[i][j]=ninj_mean[4*site*i+4*j+2]
							ndd[i][j]=ninj_mean[4*site*i+4*j+3]

							nuue[i][j]=ninj_error[4*site*i+4*j]
							nude[i][j]=ninj_error[4*site*i+4*j+1]
							ndue[i][j]=ninj_error[4*site*i+4*j+2]
							ndde[i][j]=ninj_error[4*site*i+4*j+3]

							if (nntest[i][j][x]==1):
								sz[x]+=(nuu[i][j]-nud[i][j]-ndu[i][j]+ndd[i][j])
	#							sze+=(nuue[i][j]*nuue[i][j]+nude[i][j]*nude[i][j]+ndue[i][j]*ndue[i][j]+ndde[i][j]*ndde[i][j])
								totalcount[x]+=1
								nntest[i][j][x]=-1
								nntest[j][i][x]=-1
								#print sz


				
				

#				sz=sz*sz2_mean/4/site
					sz[x]=sz[x]/(totalcount[x])
					for i in range (0, 1):
						for j in range (0, site):
					
							if (nntest[i][j][x]==-1):
								sznew[x]=(nuu[i][j]-nud[i][j]-ndu[i][j]+ndd[i][j])
								sze[x]+=math.pow(sznew[x]-sz[x],2)
								#print sz, sznew
							
								nntest[i][j][x]=1
								nntest[j][i][x]=1
								#print sz


				
					sze[x]=math.sqrt(sze[x]/(totalcount[x]))
#				sze= math.sqrt(2.0*math.pow(sze/4/site/sz,2)+math.pow(sz2_error/sz2_mean,2))*sz
	# extra division by 5 to deal with double counting of each connection. 1 for the center, 4 for when you're on the outside


				#print "Value for sz is \n"
				#print sz, sze, sz2_mean, totalcount		
	




	
				#print mu, site 		
#---------- all data in following list	
				fig1b.append( ( Uvalue, T, mu, site, sz2_mean, sz2_error, sz, sze, distance))

				probe_file=open('sz'+str(site)+str(T)+'-probe.dat', 'w+')
				for x in range (0, topval):
					probe_file.write(str(distance[x])+" "+str(sz[x])+" "+str(sze[x])+"\n")

				probe_file.close()
#---------- delete elements in file lists in loop
		del fileslist[:]
		

	
			





	os.chdir(start_directory)
	datasite=[]

#	sorted(myList, key=lambda x: x[1])
# sort data in list to get what you want 


#create complete database
	
	database_file=open('database-sz'+str(site)+'-allneighbours.dat', 'w+')
	for item in fig1b:
		database_file.write(str(item[0])+" "+str(item[1])+" "+str(item[2])+" "+ str(item[3])+" "+str(item[4])+" "+str(item[5])+" "+str(item[6])+" "+str(item[7])+" "+str(item[8])+"\n")
		


#	want_U=8
#	want_T=1.0
#	want_site=1
#	want_mu=0.0
#	for item in fig1b:
#		if abs(item[0]-want_U)<0.1 and abs(float(item[2]) - want_mu) < 0.001 and abs(float(item[1]) - want_T) < 0.001:
#			datasite.append((item[4], 1.0/item[4], item[3]))
#		
#	datasite=sorted(datasite, key=lambda x: x[1])
#	print datasite
#	

## print to file
#	fig1d_file = open('energiesfor-T'+str(want_T)+'-mu'+str(want_mu)+'.dat', 'w+')
#	for item in datasite:
#		fig1d_file.write(str(item[0])+" "+str(item[1])+" "+str(item[2])+"\n")

	

if __name__ == "__main__":
    main(sys.argv[1:])






