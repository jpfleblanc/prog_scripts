import os, shutil, distutils.dir_util



for nfreqvalue in ["10","20", "40", "100", "300", "800", "900", "1024"]:



# this generates parms
	os.system("perl -W /u/jleblanc/Hubbard/james_cluster_scripts/extract3.pl "+nfreqvalue+" > parms")

#grab parms and organize them 
	print " "
	print os.getcwd()
	print " "

	o=open('parms','r')

	wordlist=[]

	for line in o:
		words =line.split()
		i=0
#	print words
		for word in words:
	
			wordlist.append(word)
#			print(word)
#			print(wordlist)
		
		if 'LATTICE' in wordlist:
			#print wordlist
			lattice=wordlist[2][:-1].strip()
			print('Lattice is value '+lattice)
			del wordlist[:3]
		if 'MU' in wordlist:
			#print wordlist
			mu=wordlist[5][:-1].strip()
			print('MU is value '+mu)
			del wordlist[:]
		if 'NFREQ' in wordlist:
			#print wordlist
			nfreq=wordlist[11]
			print('nfreq is value '+nfreq)
			del wordlist[:40]
		if 'BETA' in wordlist:
			beta=wordlist[2][:-1].strip()
			#beta=beta[:-1].strip()
			print('BETA is value '+beta)
			del wordlist[:40]
		if 'U' in wordlist:
			Uvalue=wordlist[2][:-1].strip()
			print('U is value '+Uvalue)
			del wordlist[:40]
		if 'DENSITY' in wordlist:
			density=wordlist[2]
			print('Density is value '+ density)
			del wordlist[:40]
		if 'SELFENERGY_FILE' in wordlist:
			selfefile=wordlist[2]
			print('Selfefile is value '+ selfefile)
			del wordlist[:40]
		if 'SITES' in wordlist:
			sites=wordlist[2][:-1].strip()
			print('SITES is value '+ sites)
			del wordlist[:40]

	o.close()

	largestIter=selfefile[11:].strip()
	print 'Largest iteration is ' +largestIter

	imGfile='G_omega_'+largestIter
	reGfile='G_omegareal_'+largestIter
	print 'Looking for files '+imGfile+' and '+reGfile
	
	optionstr=' --im_g_file '+imGfile+' --re_g_file '+reGfile+' --sigma_file '+selfefile+' --nfreq '+nfreq+' --nsite '+sites+' --mu '+mu+' --beta '+beta+' --U '+Uvalue+' --n '+density


# this generates eval.h5
	os.system("echo -n \"  " + nfreqvalue+" \" >energy.dat && /u/jleblanc/New/alps_svn/Energy/energy "+ 	optionstr+">> ../energy.dat")






