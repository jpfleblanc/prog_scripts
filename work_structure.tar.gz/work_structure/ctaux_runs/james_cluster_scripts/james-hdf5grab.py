import sys
#uncomment to run on garching
sys.path.append('/u/jleblanc/software/h5py-2.0.1/base/usr/local/lib64/python2.6/site-packages')
import sys, getopt;
import os, os.path, shutil, distutils.dir_util,numpy,h5py
from numpy import array,average
import re
import math
import resource

from linreg import linreg

from collections import namedtuple

#simStructure = namedtuple("simStructure", "density mu sites")

def natural_sort(l): 
    convert = lambda text: int(text) if text.isdigit() else text.lower() 
    alphanum_key = lambda key: [ convert(c) for c in re.split('([0-9]+)', key) ] 
    return sorted(l, key = alphanum_key)


def main(argv):
#  U="8"
#  LATTICE="Betts2D-1A"
#  SITES=1
#  try:                                
#    opts, args = getopt.getopt(argv, "hULs", ["help", "U=", "lattice=","sites="])
#  except getopt.GetoptError:          
#    usage()                         
#    sys.exit(2)                     
#  for opt, arg in opts:
#    if opt in ("-h", "--help"):
#      usage()                     
#      sys.exit()                  
#    elif opt in("-L","--lattice"):
#      LATTICE = arg                 
#    elif opt in ("-U", "--U"):
#      U = arg 
#    elif opt in ("-s", "--sites"):
#      SITES =arg 
  resource.setrlimit(resource.RLIMIT_NOFILE, (4096, 4096))
  eval()

def usage():
  print("call program with -U for U, --sites= for # sites, --lattice= for lattice")

def eval():
 
	sitelist=[]
	site_folderlist=[]

	fileslist=[]

	temp_mu_folders=[]
	fig1b=[]

	start_directory=os.getcwd()

	if os.path.exists(os.getcwd()+"/sim.h5"):
		#print("sim.h5 exists in folder"+os.getcwd()+"/"+folder_item+"/sim.h5")
		
		
#--------- read in relevant data from sim.h5
		f = h5py.File(os.getcwd()+"/sim.h5", 'r')

		#print folder_item
		#print f["/parameters/MU"].value
		if f["/parameters/MU"].value<=0:# and folder_item =="Betts2D-1A_U8_T2.0_mu0":
			
			Sign=(f["/simulation/results/Sign/mean/value"].value)
			
			if "/simulation/results/density_up_times_sign/mean/value" in f:
				density_mean =(f["/simulation/results/density_up_times_sign/mean/value"].value+f["/simulation/results/density_down_times_sign/mean/value"].value)*0.5
				density_mean = sum(density_mean)/float(len(density_mean))/Sign
				density_mean_err =(f["/simulation/results/density_up_times_sign/mean/error"].value+f["/simulation/results/density_down_times_sign/mean/error"].value)*0.5
				density_mean_err = sum(density_mean_err)/math.sqrt(float(len(density_mean_err)))/Sign
				doubleoc_mean=(f["/simulation/results/doubleoc_times_sign/mean/value"].value)	
				doubleoc_mean= sum(doubleoc_mean)/float(len(doubleoc_mean))	/Sign
				doubleoc_error=(f["/simulation/results/doubleoc_times_sign/mean/error"].value)
				doubleoc_error=sum(doubleoc_error)/float(len(doubleoc_error))/Sign

				sz2_mean=(f["/simulation/results/Sz_2_tot_times_sign/mean/value"].value)/Sign
				sz2_error=(f["/simulation/results/Sz_2_tot_times_sign/mean/error"].value)/Sign
			else:
				density_mean =(f["/simulation/results/density_up/mean/value"].value+f["/simulation/results/density_down/mean/value"].value)*0.5
				density_mean = sum(density_mean)/float(len(density_mean))/Sign
			
				density_mean_err =(f["/simulation/results/density_up/mean/error"].value+f["/simulation/results/density_down/mean/error"].value)*0.5
				density_mean_err = sum(density_mean_err)/math.sqrt(float(len(density_mean_err)))/Sign
			
#sum(i*i for i in density_mean_err)


				doubleoc_mean=(f["/simulation/results/doubleoc/mean/value"].value)	
				doubleoc_mean= sum(doubleoc_mean)/float(len(doubleoc_mean))	/Sign
				doubleoc_error=(f["/simulation/results/doubleoc/mean/error"].value)
				doubleoc_error=sum(doubleoc_error)/float(len(doubleoc_error))/Sign

				sz2_mean=(f["/simulation/results/Sz_2_tot/mean/value"].value)/Sign
				sz2_error=(f["/simulation/results/Sz_2_tot/mean/error"].value)/Sign
				
			mu=f["/parameters/MU"].value
			site=f["/parameters/SITES"].value
			beta=f["/parameters/BETA"].value
			T=1.0/beta
			nfreq=f["/parameters/NMATSUBARA"].value	
			Uvalue=f["/parameters/U"].value	

#------- get energy parameters
			
			print "Sign is equal to " + str(Sign)
			

			


			
#---------- delete elements in file lists in loop
	del fileslist[:]
	


	





	os.chdir(start_directory)
	datasite=[]

#	sorted(myList, key=lambda x: x[1])
# sort data in list to get what you want 


#create complete database

	


#	want_U=8
#	want_T=1.0
#	want_site=1
#	want_mu=0.0
#	for item in fig1b:
#		if abs(item[0]-want_U)<0.1 and abs(float(item[2]) - want_mu) < 0.001 and abs(float(item[1]) - want_T) < 0.001:
#			datasite.append((item[4], 1.0/item[4], item[3]))
#		
#	datasite=sorted(datasite, key=lambda x: x[1])
#	print datasite
#	

## print to file
#	fig1d_file = open('energiesfor-T'+str(want_T)+'-mu'+str(want_mu)+'.dat', 'w+')
#	for item in datasite:
#		fig1d_file.write(str(item[0])+" "+str(item[1])+" "+str(item[2])+"\n")

	

if __name__ == "__main__":
    main(sys.argv[1:])






