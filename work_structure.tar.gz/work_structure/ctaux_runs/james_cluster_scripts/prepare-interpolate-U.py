import sys
#uncomment to run on garching
sys.path.append('/u/jleblanc/software/h5py-2.0.1/base/usr/local/lib64/python2.6/site-packages')
import sys, getopt;
import os, os.path, shutil, distutils.dir_util,numpy,h5py
from numpy import array,average
import re
import math

from collections import namedtuple


start_directory=os.getcwd()
print("Starting in "+start_directory)

def natural_sort(l): 
    convert = lambda text: int(text) if text.isdigit() else text.lower() 
    alphanum_key = lambda key: [ convert(c) for c in re.split('([0-9]+)', key) ] 
    return sorted(l, key = alphanum_key)

# load ctaux.param

filename="ctaux.param"


if os.path.exists(start_directory+'/G0_omega_input'):
	print("Input file exists, continuing from where we left off\n")
else:
	print("Input file does not exist, Looking for interpolation file\n")
	if os.path.exists(start_directory+"/"+filename):
		FILE = open(filename)

		for line in FILE:
		
			s = line.split()
			#print s
			if len(s) ==3:
				#print s[0]
				if s[0] == 'BETA':
					beta= s[2]
					beta=beta[:-1].strip()
					print beta
				if s[0]== 'MU':
					mu= s[2]
					mu=mu[:-1].strip()
					print mu

				if s[0]=='NMATSUBARA':
					nmatsubara=s[2]
					nmatsubara=nmatsubara[:-1].strip()
					print nmatsubara
				if s[0]=='SITES':
					sites_wanted=s[2]
					sites_wanted=sites_wanted[:-1].strip()
					print sites_wanted

				if s[0]=='U':
					U_wanted=s[2]
					U_wanted=U_wanted[:-1].strip()

			if len(s) ==2:			
				if s[0]=='LATTICE=':
					lattice=s[1]
					#print lattice
					lattice=lattice[:-1].strip()
					print lattice
					#print "WTF"
	##_------------------ values loaded

	ref_dir= "/data/cqmp/james/Hubbard/ehsan_fig1b/Betts2D-ref"
	#ref_dir= "/u/jleblanc/Hubbard/screw-around/Betts2D-16A"


	os.chdir(ref_dir)
	folderlist= filter(os.path.isdir, os.listdir('.'))
	print folderlist

	mulist=[]
	betalist=[]
	objectlist=[]
	Ulist=[]


	for item in folderlist:
		os.chdir(ref_dir+"/"+item)
		if U_wanted in item:
			if os.path.exists(os.getcwd()+"/sim.h5"):
				f = h5py.File(os.getcwd()+"/sim.h5", 'r')

				mulist.append(f["/parameters/MU"].value)
				betalist.append(f["/parameters/BETA"].value)
				objectlist.append( (f["/parameters/MU"].value,f["/parameters/BETA"].value, os.getcwd(), abs(f["/parameters/MU"].value- float(mu)) + abs(f["/parameters/BETA"].value-float(beta) )   )   )

	if len(objectlist)==0:
		for item in folderlist:
			os.chdir(ref_dir+"/"+item)
			if os.path.exists(os.getcwd()+"/sim.h5"):
				f = h5py.File(os.getcwd()+"/sim.h5", 'r')

				mulist.append(f["/parameters/MU"].value)
				betalist.append(f["/parameters/BETA"].value)
				objectlist.append( (f["/parameters/MU"].value,f["/parameters/BETA"].value, os.getcwd(), abs(f["/parameters/MU"].value- float(mu)) + abs(f["/parameters/BETA"].value-float(beta) )   )   )

	print mulist
	print betalist

	print objectlist

	objectlist=sorted(objectlist, key=lambda x: x[3])

	chosen_dir=objectlist[0][2]

	print("Suggested using directory data in "+ chosen_dir +" as starting point")

	os.chdir(chosen_dir)

	print("I'm now in " +os.getcwd())

	#------------

	#----- next is check files to find max iteration to give to sigma-iteration

	files_list = [file for file in os.listdir(os.getcwd())]
	fileslist=[]
	#print files_list

	# save ClusterMomenta so not overridden by sigma_interpolate program

	for file_item in files_list:
		if "ClusterMomenta" in file_item and "_tmp" not in file_item:
			shutil.copy(file_item, file_item+'_tmp')



	for file_item in files_list:
		if "selfenergy_" in file_item:
			if "realspace_" not in file_item:
				tmpfile=file_item[11:].strip()
				fileslist.append(tmpfile)
	fileslist=natural_sort(fileslist)		
	print("Length of fileslist"+ str(len(fileslist)))
	#------------ if an iteration completed
	
	if(len(fileslist)>1):# and site==1
		Iteration=int(fileslist[len(fileslist)-1])
		print("Max iteration was "+str(Iteration))


	#--- remove previous interpolations
	os.system("rm G0_omega_input_*")

	#--- run interpolation


	interpolate_options= ' --beta '+ beta+' --mu '+ mu +' --n_matsubara '+nmatsubara+ ' --pfile ctaux.param --lattice /home/leblanc/alps_svn/DMFT/cluster.xml --cluster '+ lattice +' --sites '+ sites_wanted +' --iteration 1 '

	print interpolate_options
	
	os.system("/home/leblanc/alps_svn/DMFT/sigma_interpolate "+interpolate_options)



	#replace original clustermomentum file
	files_list = [file for file in os.listdir(os.getcwd())]

	for file_item in files_list:
		if "ClusterMomenta_tmp" in file_item:
			shutil.copy(file_item, "ClusterMomenta")
			os.remove(file_item)



	#grab interpolated file
	files_list_2 = [file for file in os.listdir(os.getcwd())]

	for file_item in files_list_2:
		if "G0_omega_input_" in file_item:
			interpolated_file=file_item



	print interpolated_file

	#interpolated_file=''

	#move interpolated file to starting directory if it exists (2 scripts running simultaniously may rm the file before it is moved?)

	if os.path.isfile(os.getcwd()+'/'+interpolated_file)== True:
		print 'was true... moving starting G0 file'
		shutil.copy(interpolated_file, start_directory+'/G0_omega_input')

# move back to starting directory
os.chdir(start_directory)




