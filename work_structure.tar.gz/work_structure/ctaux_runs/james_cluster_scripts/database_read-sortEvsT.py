import sys
#uncomment to run on garching
sys.path.append('/u/jleblanc/software/h5py-2.0.1/base/usr/local/lib64/python2.6/site-packages')
import sys, getopt;
import os, os.path, shutil, distutils.dir_util,numpy,h5py
from numpy import array,average
import re
import math
import resource

from linreg import linreg

from collections import namedtuple

#simStructure = namedtuple("simStructure", "density mu sites")

def natural_sort(l): 
    convert = lambda text: int(text) if text.isdigit() else text.lower() 
    alphanum_key = lambda key: [ convert(c) for c in re.split('([0-9]+)', key) ] 
    return sorted(l, key = alphanum_key)


def main(argv):
#  U="8"
#  LATTICE="Betts2D-1A"
#  SITES=1
#  try:                                
#    opts, args = getopt.getopt(argv, "hULs", ["help", "U=", "lattice=","sites="])
#  except getopt.GetoptError:          
#    usage()                         
#    sys.exit(2)                     
#  for opt, arg in opts:
#    if opt in ("-h", "--help"):
#      usage()                     
#      sys.exit()                  
#    elif opt in("-L","--lattice"):
#      LATTICE = arg                 
#    elif opt in ("-U", "--U"):
#      U = arg 
#    elif opt in ("-s", "--sites"):
#      SITES =arg 
  resource.setrlimit(resource.RLIMIT_NOFILE, (4096, 4096))
  eval()

def usage():
  print("call program with -U for U, --sites= for # sites, --lattice= for lattice")

def eval():
 

	sitelist=[]
	site_folderlist=[]

	fileslist=[]

	temp_mu_folders=[]
	alldata=[]
	datasite=[]

	read_file=open('database.dat', 'r')
	a  = numpy.loadtxt(read_file, unpack=True)
	#Uvalue, T, mu, etot, site,  doubleoc_mean, doubleoc_error, ekin_mean, ekin_error, epot_mean, epot_error, density_mean, density_mean_err, sz2_mean, sz2_error  = numpy.loadtxt(read_file, unpack=True)
	read_file.close()


	print a[14][0]
	print len(a[0])

	for x in range(0,len(a[0]-1)):
		alldata.append( (a[0][x],a[1][x],a[2][x],a[3][x],a[4][x],a[5][x],a[6][x],a[7][x],a[8][x],a[9][x],a[10][x],a[11][x],a[12][x],a[13][x],a[14][x]))

	#print alldata[0]

	

#	for element in len(Uvalue):
#		fig1b.append( ( Uvalue[element], T[element], mu[element], etot[element], site[element],  doubleoc_mean[element], doubleoc_error[element], ekin_mean[element], ekin_error[element], epot_mean[element], epot_error[element], density_mean[element], density_mean_err[element], sz2_mean[element], sz2_error[element]))


#	print fig1b[0]

	
	
	templist=[]
	want_U=8
	want_T=1.0
	want_site=34
	want_mu=0.0
	for item in alldata:
		#if abs(item[0]-want_U)<0.1 and abs(float(item[2]) - want_mu) < 0.001 and abs(float(item[1]) - want_T) < 0.001 and item[4]>9:
		if abs(item[0]-want_U)<0.1 and abs(float(item[2]) - want_mu) < 0.001  and abs(item[4]-want_site)<.001:
			datasite.append((item[1],item[3], math.sqrt(item[8]*item[8]+item[10]*item[10]) ))
			if item[1] not in templist:
				templist.append(item[1])
		
	datasite=sorted(datasite, key=lambda x: x[0])
	templist=sorted(templist, key=lambda x: x)
	#print datasite


## print to file
	fig1d_file = open('EnergyvsT-site-'+str(want_site)+'-U'+str(want_U)+'-mu'+str(want_mu)+'.dat', 'w+')
	for item in datasite:
		#print math.isnan(item[2])
		if math.isnan(item[2]):
			#print item[2], str(item[2])
			fig1d_file.write(str(item[0])+" "+str(item[1])+" "+str(0.0)+"\n")
		else:
			fig1d_file.write(str(item[0])+" "+str(item[1])+" "+str(item[2])+"\n")
		

	#print b, var_b
	

if __name__ == "__main__":
    main(sys.argv[1:])






