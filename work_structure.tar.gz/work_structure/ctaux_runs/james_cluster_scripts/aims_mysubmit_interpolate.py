import sys
import os

name=sys.argv[1]
walltime=sys.argv[2]
nodes=sys.argv[3]


#print "#!/bin/bash"
#print "#PBS -S /bin/bash"
#print "#PBS -m be"
#print "#PBS -M leblanc@pks.mpg.de"
#print "#PBS -N "+name
#print "#PBS -q "+queue
#print "#PBS -l nodes="+nodes
#print "#PBS -l walltime="+walltime

#print "cd "+os.getcwd()

#print "echo *** running dmft job ***"
#print "/home/leblanc/alps_svn/DMFT/dmft ctaux.param"
#print "echo *** done running dmft job, exiting ***"


print "#$ -S /bin/bash"
print "#$ -cwd"
print "# put output and error to following files"
print "#$ -o outfile"
print "#$ -e errfile"
print "#$ -l h_rt=" +walltime
print "#$ -pe impi "+nodes
print "#$ -notify"
print "#$ -m abes"

print "cd "+os.getcwd()
print "hostname"
print "echo $PATH"
print "module load impi/4.0.3 python/scipy/2011.06"
print "python /u/jleblanc/Hubbard/james_cluster_scripts/prepare-interpolate.py" 
print "/u/jleblanc/New/alps_svn/DMFT/dmft ctaux.param"
print "echo *** done running dmft job, exiting ***"

