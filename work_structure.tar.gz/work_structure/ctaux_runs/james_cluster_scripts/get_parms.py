import os, shutil, distutils.dir_util, sys, fileinput


wordlist=[]

for line in fileinput.input():
	words =line.split()
	i=0
#	print words
	for word in words:

		wordlist.append(word)
#		print(word)
#		print(wordlist)
		
	if 'LATTICE' in wordlist:
		lattice=wordlist[2]
		print('Lattice is value '+lattice)
		del wordlist[:3]
	if 'MU' in wordlist:
		mu=wordlist[2]
		print('MU is value '+mu)
		del wordlist[:40]
	if 'NFREQ' in wordlist:
		nfreq=wordlist[2]
		print('nfreq is value '+nfreq)
		del wordlist[:40]
	if 'BETA' in wordlist:
		beta=wordlist[2]
		print('BETA is value '+beta)
		del wordlist[:40]
	if 'U' in wordlist:
		Uvalue=wordlist[2]
		print('U is value '+Uvalue)
		del wordlist[:40]
	if 'DENSITY' in wordlist:
		density=wordlist[2]
		print('Density is value '+ density)
		del wordlist[:40]
	if 'SELFENERGY_FILE' in wordlist:
		selfefile=wordlist[2]
		print('Selfefile is value '+ selfefile)
		del wordlist[:40]
	if 'SITES' in wordlist:
		sites=wordlist[2]
		print('SITES is value '+ sites)
		del wordlist[:40]


largestIter=selfefile[11:].strip()
print 'Largest iteration is ' +largestIter

imGfile='G_omega_'+largestIter
reGfile='G_omegareal_'+largestIter
print 'Looking for files '+imGfile+' and '+reGfile



	

