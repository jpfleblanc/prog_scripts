import os, shutil, distutils.dir_util

MAX_TIME="360"
MAX_IT="18"
vertex_max_time="4800"
vertex_max_it="1"
#U="8"
#tprime="0"
SITES="1"
LATTICE="Betts2D-1A"
mu="0"

WALLTIME="6:00:00"#"75:00:00"
nodes=2
NCPU=str(int(nodes*16))
#"1:ppn=1";
queue="cnms10tq"
#[2.0,1.8,1.6,1.4,1.2,1.,0.9,0.8,0.7,0.6,0.5,0.45,0.4,0.35,0.3]:
#["-10","-9","-8","-7","-6","-5","-4","-3.5","-3","-2.5","-2","-1.5","-1","-0.5","0"]:
#[2.0, 1.0, 0.82, 0.55, 0.25]:
#["-4.0","-3.5","-3","-2.5","-2","-1.5","-1","-0.5","0"]:
#	[10.0, 8.0, 6.0, 4.0, 3.0,2.5,2.0,1.8,1.6,1.4,1.2,1.,0.9,0.8,0.7,0.6,0.5,0.45,0.4,0.35,0.3,0.25, 0.2, 0.15, 0.1, 0.05]:
for U in [ "7.0","7.4", "7.7"]:#, "1.5", "2.0", "2.5", "3.0", "3.5", "4.0"]:#,"2.0", "4.0", "6.0", "8.0", "12.0"]:
	for T in [0.2]:#[0.1, 0.2, 0.3, 0.4]:
		beta=str(1./T)
		for mu in ["0.0", "-1.5", "1.5"]:
			for tprime in ["0.0", "-0.1", "-0.2", "-0.3"]:	
				dirname = LATTICE+"_U"+U+"_T"+str(T)+"_mu"+mu+"_tp"+tprime
				jobname = "S"+SITES+"U"+U+"T"+str(T)+"m"+mu+"_tp"+tprime
				if os.path.isdir(dirname):
					print("path "+dirname+" exists. remove to restart.")
					continue
				distutils.dir_util.copy_tree("../../U_template_james_novertex_simons_filling",dirname)
		
				o = open(dirname+"/ctaux.param",'w')
				for line in open("../../U_template_james_novertex_simons_filling/ctaux.param"):
					line = line.replace("MAX_TIME = XXX","MAX_TIME = "+MAX_TIME)
					line = line.replace("MAX_IT = XXX","MAX_IT = "+MAX_IT)
					line = line.replace("BETA = XXX","BETA = "+beta)
					line = line.replace("MU = XXX","MU = "+mu)
					line = line.replace("U = XXX","U = "+U)
					line = line.replace("t' = XXX","t' = "+tprime)
					line = line.replace("SITES = XXX","SITES = "+SITES)
					line = line.replace("LATTICE = XXX","LATTICE= "+LATTICE)
					line = line.replace("FILLING = XXX;","")#"FILLING = "+filling)
					if queue=="cnmsq":
						line = line.replace("CTAUX_SUB_NGS","CTAUX_SUB_NGS_cnms")
					o.write(line)
				o.close()
				o = open(dirname+"/ctaux_vertex.param",'w')
				for line in open("../..//U_template_james_novertex_simons_filling/ctaux.param"):
					line = line.replace("MAX_TIME = XXX","MAX_TIME = "+vertex_max_time)
					line = line.replace("MAX_IT = XXX","MAX_IT = "+vertex_max_it)
					line = line.replace("BETA = XXX","BETA = "+beta)
					line = line.replace("MU = XXX","MU = "+mu)
					line = line.replace("U = XXX","U = "+U)
					line = line.replace("t' = XXX","t' = "+tprime)
					line = line.replace("SITES = XXX","SITES = "+SITES)
					line = line.replace("LATTICE = XXX","LATTICE= "+LATTICE)
					line = line.replace("FILLING = XXX;","")#"FILLING = "+filling)
					if queue=="cnmsq":
						line = line.replace("CTAUX_SUB_NGS","CTAUX_SUB_NGS_cnms")
					o.write(line)
				o.close()

	   
				print dirname+" : walltime: "+WALLTIME;
				os.system("cd "+dirname+" && rm -f G* && rm -f sim.h5 && python ../../../submit_template/mysubmit_DF_stampede.py "+dirname+" "+WALLTIME+" "+NCPU+" "+jobname+" > james_submit.pbs  && sbatch james_submit.pbs && cd ..")
				os.system("echo 'Program is Running'> "+dirname+"/inqueue.txt")
	#    os.system("cd "+dirname+" && rm -f G* && rm -f sim.h5 && python ../../mysubmit.py "+dirname+" "+WALLTIME+" "+NCPU+" > james_submit.pbs")
	# && qsub -q "+queue+" submit.pbs && cd ..")

