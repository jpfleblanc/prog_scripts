import sys
import os

#name=sys.argv[1]
workdir=sys.argv[1]
walltime=sys.argv[2]
#nodes=sys.argv[4]
ncpu=sys.argv[3]
jobname=sys.argv[4]


#print "#!/bin/bash"
#print "#PBS -S /bin/bash"
#print "#PBS -m be"
#print "#PBS -M leblanc@pks.mpg.de"
#print "#PBS -N "+name
#print "#PBS -q "+queue
#print "#PBS -l nodes="+nodes
#print "#PBS -l walltime="+walltime

#print "cd "+os.getcwd()

#print "echo *** running dmft job ***"
#print "/home/leblanc/alps_svn/DMFT/dmft ctaux.param"
#print "echo *** done running dmft job, exiting ***"


#print "#$ -S /bin/bash"
#print "#$ -cwd"
#print "# put output and error to following files"
#print "#$ -o outfile"
#print "#$ -e errfile"
#print "#$ -l h_cpu="+walltime+",h_fsize=10G,h_rss=8000M,s_cpu="+walltime+" "
#print "#$ -pe smp "+nodes
#print "#$ -notify"
#print "#$ -m abes"
#print "#$ -N "+jobname
#!/bin/bash -l
#SBATCH -p regular      
#SBATCH -N 8  
#SBATCH -n 256
#SBATCH -c 8         
#SBATCH -t 00:10:00          

#SBATCH -J 16myjob        
#SBATCH -o myjob.%j.out   
#SBATCH -e myjob.%j.err   
#SBATCH -p normal    
#SBATCH -N 2              
#SBATCH -n 16             
#SBATCH -t 24:00:00       
#SBATCH -A TG-DMR130036   


print "#!/bin/bash -l"
print "#SBATCH -p normal"
print "#SBATCH -n "+ ncpu
print "#SBATCH -t "+walltime
print "#SBATCH -J "+jobname
print "#SBATCH -e errfile"  #could add .$PBS_JOBID
print "#SBATCH -o outfile"
print "#SBATCH -A TG-DMR130036"

#print "#PBS -M leblanc@pks.mpg.de"
#print "#SBATCH -m abe"
#print "#PBS -V"

#print "cd $PBS_O_WORKDIR"
#print "export LANG=\"C\""
#aprun -n 1024 ./my_executable



#print "cd "+os.getcwd()

print "echo 'Program is Running'> isrunning.txt"

print "echo Starting dmft code"
print "//home1/03773/jamesleb/alps_git/DMFT/dmft ctaux.param"

print "echo DMFt code complete - running ctaux with internal loop"

print "ibrun /home1/03773/jamesleb/alps_git/DMFT-solvers/CTAUX_SUB_NGS/ctaux_mpi tmp_solver_file.in.h5 tmp_solver_file.out.h5"

print "Creating vertex folder and preparing"
print "mkdir vertex_run"
print "cd vertex_run"
print "cp ../G0omega_output G0_omega_input"
print "cat ../ctaux_vertex.param ../../../../U_template_james_vertex/vertex_append_DCA.param > ctaux_vertex.param"

print "echo Starting Vertex Run"

print "//home1/03773/jamesleb/alps_git/DMFT/dmft ctaux_vertex.param"
print "ibrun /home1/03773/jamesleb/alps_git/DMFT-solvers/CTAUX_SUB_NGS/ctaux_mpi tmp_solver_file.in.h5 tmp_solver_file.out.h5"



print "echo *** done running dmft job, exiting ***"
print "rm isrunning.txt"
print "rm inqueue.txt"
