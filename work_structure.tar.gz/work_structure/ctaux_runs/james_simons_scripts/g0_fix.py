import sys
#uncomment to run on garching
#sys.path.append('/u/jleblanc/software/h5py-2.0.1/base/usr/local/lib64/python2.6/site-packages')
import sys, getopt;
import os, os.path, shutil, distutils.dir_util,numpy,h5py
from numpy import *
import re
import math
import resource

import numpy as np


def main(argv):



	eval(argv)


def eval(argv):

	#x= np.loadtxt("test", dtype=complex)

	outfile=open(argv[1],"w+")
	

	f=open(argv[0], "r")
	lines=f.readlines()

	outlines=''
	for i in lines:
		#print "I'm at i=" +i
		thisline=i.split(" ")
		#print thisline

		for number in thisline:
			#print number
			#print 'number is '+number
			if (number != '(0,0)'):
				#print "adding number"
				#print number
				outlines=outlines+' '+number


		
			#print outlines
	#print x
		
		
	outfile.write(outlines)
	outfile.close()

#	print "Outlines is"
#	print outlines








if __name__ == "__main__":
    main(sys.argv[1:])
