import sys
#uncomment to run on garching
#sys.path.append('/u/jleblanc/software/h5py-2.0.1/base/usr/local/lib64/python2.6/site-packages')
import sys, getopt;
import os, os.path, shutil, distutils.dir_util,numpy,h5py
from numpy import *
import re
import math
import resource

import numpy as np



#simStructure = namedtuple("simStructure", "density mu sites")

def natural_sort(l): 
    convert = lambda text: int(text) if text.isdigit() else text.lower() 
    alphanum_key = lambda key: [ convert(c) for c in re.split('([0-9]+)', key) ] 
    return sorted(l, key = alphanum_key)


def main(argv):
#  U="8"
#  LATTICE="Betts2D-1A"
#  SITES=1
#  try:                                
#    opts, args = getopt.getopt(argv, "hULs", ["help", "U=", "lattice=","sites="])
#  except getopt.GetoptError:          
#    usage()                         
#    sys.exit(2)                     
#  for opt, arg in opts:
#    if opt in ("-h", "--help"):
#      usage()                     
#      sys.exit()                  
#    elif opt in("-L","--lattice"):
#      LATTICE = arg                 
#    elif opt in ("-U", "--U"):
#      U = arg 
#    elif opt in ("-s", "--sites"):
#      SITES =arg 
  resource.setrlimit(resource.RLIMIT_NOFILE, (4096, 4096))
  eval()

def usage():
  print("call program with -U for U, --sites= for # sites, --lattice= for lattice")

def eval():
 
	sitelist=[]
	site_folderlist=[]

	fileslist=[]

	temp_mu_folders=[]
	fig1b=[]

	start_directory=os.getcwd()
	print("Starting in "+start_directory)
	
		

# ---------------- Now move into Betts directories


	os.chdir(start_directory)
	print("cd " + start_directory)
	print("I am in " + os.getcwd())
	temp_mu_folders=filter(os.path.isdir, os.listdir('.'))#["Betts2D-4A_U1.10_T0.125_mu0"]#filter(os.path.isdir, os.listdir('.'))

	evdatabase=[]
	evdatabase_imag=[]
	evector_data=[]
	files_list=[]
	
	print temp_mu_folders

# --------- check for sim.h5 files
	for folder_item in temp_mu_folders:
		print "Checking for "+start_directory+"/"+folder_item
		print folder_item
		if os.path.exists(start_directory+"/"+folder_item+"/G0_omega_input"):
			os.chdir(start_directory+"/"+folder_item)
			print os.getcwd()
			os.system("python ../../../../james_simons_scripts/g0_fix.py G0_omega_input TEMPFILE")
			os.system("mv TEMPFILE G0_omega_input")
		else:
			print "checking failed for "+start_directory+"/"+folder_item
			



if __name__ == "__main__":
    main(sys.argv[1:])






