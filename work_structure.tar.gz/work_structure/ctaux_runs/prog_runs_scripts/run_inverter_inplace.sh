/home1/03773/jamesleb/alps_git/inverter/install/inverter --lattice /home1/03773/jamesleb/alps_git/DMFT/libcluster/cluster.xml --sigma ../selfenergy_18 --sim sim.h5 --task chi
