/home/jpfleblanc/alps_git/inverter/install/inverter --lattice /home/jpfleblanc/alps_git/DMFT/libcluster/cluster.xml --sigma ../selfenergy_18 --sim sim.h5 --task chi
