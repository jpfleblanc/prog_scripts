awk '$2==3.141592653589793116 {print}' chi_file.dat > chi_pislice.dat
