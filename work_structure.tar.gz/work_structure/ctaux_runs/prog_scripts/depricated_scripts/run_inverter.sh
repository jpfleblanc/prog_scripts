time -v ~/alps_git/inverter/inverter --lattice /home/jpfleblanc/alps_git/DMFT_cluster/DMFT/cluster.xml --sim //home/jpfleblanc/working_2014/xi_debugging/U2_beta10_mu0.5/sim.h5 --sigma /home/jpfleblanc/working_2014/xi_debugging/U2_beta10_mu0.5/selfenergy_4 --task neutron_lattice_susc --lattice_size 36 --lattice_name Betts2D-36A --n_omega 24 --n_Omega 10 --basename NEU

