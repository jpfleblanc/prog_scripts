/home1/03773/jamesleb/alps_core/opendf/install/bin/hub_df_cubic2d --mu 0 --input qmc_output.h5 --nbosonic 8 --df_sc_cutoff 1.0e-6 --df_sc_iter 50 --df_sc_mix 0.4 --fluct_diag 1
